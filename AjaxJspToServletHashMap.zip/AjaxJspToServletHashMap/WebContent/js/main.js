/**
 * 
 */
$(document).ready(function(){
	$("#query").submit(function(){
		
		$.ajax({
			url:'querysend',
			type:'POST',
			dataType: 'json',
			data: $('#query').serialize(),
			success: function(data){
				if(data.isValid){
					$('#queryresult').html('Result is :'+data.querytext);
					$('#queryresult').slideDown(500);
				}
				else{
					alert("Please enter your Query");
				}
			}
		});
		return false;
	});
});