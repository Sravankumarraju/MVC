$("#fetchRelaySettingmis").click(function(){
	var searchTextValue = $("#searchTextValue").val();
	if(searchTextValue == ""){
		showAlert("Please enter search result", "error");
	}
	var oMyForms=ajaxSubmit("service,key_task", "current_page","success_page","failure_page");
	oMyForms.append("searchTextValue",searchTextValue)
	fetchrelaysettingmis(oMyForms);
});

function fetchrelaysettingmis(oMyForms){
	 $.ajax({
	        url: 'mipaction_get_fetch_relay_setting_mis.relay',
	        type: 'POST',
	        async: false,     
	        cache : false,
	     	contentType : false,
	     	processData : false,          
	        data: oMyForms,
	        success: function(response_msg){   
	        	showAlert("Result executed successfully", "success")
	        },
	        error:function(response_msg){
	          //  alert('Failure, some problem'+response_msg);
           	 showAlert('Failure, some problem'+response_msg, "error");

	        }
	    });
}
