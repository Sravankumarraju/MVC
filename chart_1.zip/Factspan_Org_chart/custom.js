// Get date and time function

function getDateTime() {
    var today = new Date();
    var day = today.getDate() + "";
    var month = (today.getMonth() + 1) + "";
    var year = today.getFullYear() + "";
    var hour = today.getHours() + "";
    var minutes = today.getMinutes() + "";
    var seconds = today.getSeconds() + "";

    day = checkZero(day);
    month = checkZero(month);
    year = checkZero(year);
    hour = checkZero(hour);
    minutes = checkZero(minutes);
    seconds = checkZero(seconds);

    let dateTime = day + "/" + month + "/" + year + " " + hour + ":" + minutes + ":" + seconds

    //console.log(dateTime);

    function checkZero(data) {
        if (data.length == 1) {
            data = "0" + data;
        }
        return data;
    }

    return dateTime;
}

var importedEmpList = [];
var existingEmpList = [];
var revertChanges = [];
jQuery(document).ready(function() {
    /* Custom jQuery for the example */
    $("#show-list").click(function(e) {
        e.preventDefault();

        $("#list-html").toggle("fast", function() {
            if ($(this).is(":visible")) {
                $("#show-list").text("Hide underlying list.");
                $(".topbar").fadeTo("fast", 0.9);
            } else {
                $("#show-list").text("Show underlying list.");
                $(".topbar").fadeTo("fast", 1);
            }
        });
    });

    $("#list-html").text($("#org").html());

    $("#org").bind("DOMSubtreeModified", function() {
        $("#list-html").text("");

        $("#list-html").text($("#org").html());

        prettyPrint();
    });

    getData();
    async function getData() {
        let serialNum = 1;
        //const response = await fetch("Org_file.csv");
        const response = await fetch("Org_Structure.csv");
        const data = await response.text();
        //console.log(data);

        const rows = data.split("\n").slice(1);
        //console.log(rows);
        rows.forEach((elt) => {
            const row = elt.split(",");
            //console.log(row);
            importedEmpList.push({
                sNo: serialNum,
                empName: row[1],
                empId: Number(row[2]),
                empDesg: row[3],
                repMangId: Number(row[4]),
                repMangName: row[5],
                //dept: row[6],
                dateTime: getDateTime(),
            });
            //console.log("importedEmpList - ",importedEmpList)
            existingEmpList.push({
                sNo: serialNum,
                empName: row[1],
                empId: Number(row[2]),
                empDesg: row[3],
                repMangId: Number(row[4]),
                repMangName: row[5],
                //dept: row[6],
                dateTime: getDateTime(),
            });
            // if(row[3]!=""){
            //   <li></li>
            // }
            serialNum += 1;
        });
        revertChanges.push(existingEmpList);
        console.log("importedEmpList - ", importedEmpList);
        console.log("existingEmpList - ", existingEmpList);
        console.log("revertChanges - ", revertChanges);
        //const mainParentEmpId = importedEmpList.find(emp => emp.repMangId == 0);
        $("#orgData").html(getReportingEmpData(0, true));
        $("#org").jOrgChart({
            chartElement: "#chart",
            dragAndDrop: true,
        });
    }
});
let revertCount = 0;

function revertCountFun() {
    if (revertChanges.length > 0 && revertCount > 0) {
        revertCount = revertCount - 1;
    }
    return revertCount;
}

function getReportingEmpData(repMangId, isFirstRecord) {
    // const mainParentEmpId = importedEmpList.find(emp => emp.repMangId == 0);
    // const reportes = importedEmpList.filter(
    //     (emp) => emp.repMangId == repMangId
    // );
    revertCountFun()
    const mainParentEmpId = revertChanges[revertCount].find(emp => emp.repMangId == 0);
    const reportes = revertChanges[revertCount].filter(
        (emp) => emp.repMangId == repMangId
    );
    let reportesData = "<ul " + (isFirstRecord ? "id='org'" : "") + ">";
    //if(isFirstRecord){
    // reportesData = reportesData + "<li> <span>"+employee.empName+"</span> <br><br><br><span>"+employee.empDesg+" (0)</span>";
    //}
    let rEmpData = "";
    reportes.forEach((emp) => {
        //rEmpData = rEmpData + "<li> <span class='emp-name'>"+emp.empName+"</span> <br><br><br><span class='emp-desg'>"+emp.empDesg+" ("+importedEmpList.filter(iemp => iemp.repMangId == emp.empId).length+")</span>";
        let empCardClassName = '';
        if (emp.empDesg === 'VP') {
            empCardClassName = 'class-vp';
        } else if (emp.empDesg === 'AD') {
            empCardClassName = 'class-ad';
        } else if (emp.empDesg === 'SM') {
            empCardClassName = 'class-sm';
        } else if (emp.empDesg === 'M') {
            empCardClassName = 'class-m';
        } else {
            empCardClassName = 'class-default';
        }
        rEmpData =
            rEmpData +
            "<li class= '" + empCardClassName + " " + ((emp.collapsed !== undefined) ?
                (emp.collapsed ? 'collapsed' : '') :
                (!(repMangId == 0) ? 'collapsed' : '')) +
            "' > <span class='emp-name " + empCardClassName + "-name'>" +
            emp.empName +
            "</span> <br><br><span class='emp-desg " + empCardClassName + "-desg'>" +
            emp.empDesg +
            "</span><br> <span class='" + empCardClassName + "-count'>DR - (" +
            importedEmpList.filter((iemp) => iemp.repMangId == emp.empId)
            .length +
            ")</span> <span class='" + empCardClassName + "-count' >TR - (" +
            getChildListLength(emp.empId) + ") </span>" +
            "<input type='hidden' class='emp-id' value='" +
            emp.empId +
            "'><input type='hidden' class='emp-repMangId' value='" +
            emp.repMangId +
            "'><input type='hidden' class='emp-repMangName' value='" +
            emp.repMangName +
            "'>";
        //"'><span class='emp-dept' style='display:none'>" + emp.dept + "</span>";

        rEmpData = rEmpData + getReportingEmpData(emp.empId, false);

        rEmpData = rEmpData + "</li>";
    });
    if (rEmpData != "") {
        reportesData = reportesData + rEmpData;
    }

    reportesData = reportesData + "</ul>";


    return reportesData;
}

function getChildListLength(repMangId) {
    const reportes = importedEmpList.filter(
        (emp) => emp.repMangId == repMangId
    );
    let len = reportes.length;
    reportes.forEach((emp) => {
        len = len + getChildListLength(emp.empId);
    });
    return len;
}

function FetchChild() {
    var data = [];
    $("#org > li").each(function() {
        data.push(buildJSON($(this)));
    });

    return data;
}

let serialNumber = 1;


function buildJSON($li) {
    var subObj = {
        name: $li.contents().eq(0).text().trim() ||
            $li.find('[class="emp-name"]').text().trim(),
        // "icon": $li.find('i').attr('class'),
        // "to": $li.find('a').attr('href')
    };
    importedEmpList.push({
        sNo: serialNumber,
        empName: $li.find(">.emp-name").text(),
        empId: Number($li.find(".emp-id").val()),
        empDesg: $li.find(">.emp-desg").text(),
        repMangId: Number($li.find(".emp-repMangId").val()),
        repMangName: $li.find(".emp-repMangName").val(),
        //dept: $li.find(".emp-dept").val(),
        collapsed: $li.hasClass('collapsed'),
        dateTime: getDateTime()

    });
    serialNumber = serialNumber + 1;
    //console.log("importedEmpList Json - ",importedEmpList);
    $li
        .children("ul")
        .children()
        .each(function() {
            if (!subObj.children) {
                subObj.children = [];
            }
            subObj.children.push(buildJSON($(this)));
        });
    return subObj;
}

function resetAndUpdate() {
    console.log("reset");
    importedEmpList = [];
    var obj = FetchChild();
    revertChanges.push(importedEmpList);
    console.log("importedEmpList Reset - ", importedEmpList);
    console.log("revertChanges - ", revertChanges);
    console.log("revert Changes length - " + revertChanges.length);
    $("#orgData").html(getReportingEmpData(0, true));
    $("#org").jOrgChart({
        chartElement: "#chart",
        dragAndDrop: true,
    });
    if (revertChanges.length > 0) {
        $('#revert').prop('disabled', false);
    }
}

//Converting Json to CSV file

function convertToCSV(objArray) {
    var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    var str = '';

    for (var i = 0; i < array.length; i++) {
        var line = '';
        for (var index in array[i]) {
            if (line != '') line += ','

            line += array[i][index];
        }

        str += line + '\r\n';
    }

    return str;
}

function exportCSVFile(headers, items, fileTitle) {
    if (headers) {
        items.unshift(headers);
    }

    // Convert Object to JSON
    var jsonObject = JSON.stringify(items);

    var csv = this.convertToCSV(jsonObject);

    var exportedFilenmae = fileTitle + '.csv' || 'export.csv';

    var blob = new Blob([csv], {
        type: 'text/csv;charset=utf-8;'
    });
    if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, exportedFilenmae);
    } else {
        var link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            var url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", exportedFilenmae);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
}

function download() {
    var headers = {
        sNo: 'S No',
        empName: 'Name of the Employee'.replace(/,/g, ''), // remove commas to avoid errors
        empId: "Emp ID",
        empDesg: "Designation".replace(/,/g, ''),
        repMangId: "Project Manager ID".replace(/,/g, ''),
        repMangName: "Reporting Manager".replace(/,/g, ''),
        //dept: "Department".replace(/,/g, ''),
        dateTime: "Date and Time".replace(/,/g, '')
    };

    itemsNotFormatted = importedEmpList;

    var itemsFormatted = [];

    // format the data
    itemsNotFormatted.forEach((item) => {
        itemsFormatted.push({
            sNo: item.sNo,
            empName: item.empName.replace(/,/g, ''), // remove commas to avoid errors,
            empId: item.empId,
            empDesg: item.empDesg.replace(/,/g, ''),
            repMangId: item.repMangId,
            repMangName: item.repMangName.replace('\r', '').replace('\n', ''),
            //dept: item.dept,
            dateTime: item.dateTime.replace(/,/g, ''),
        });
    });

    var fileTitle = 'Org_Structure_gen'; // or 'my-unique-title'

    exportCSVFile(headers, itemsFormatted, fileTitle); // call the exportCSVFile() function to process the JSON and trigger the download
}